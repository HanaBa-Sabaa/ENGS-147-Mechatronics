#ifndef VOLTAGE2CONTROL_H
#define VOLTAGE2CONTROL_H

#include <Arduino.h>

int getPWM(float voltage);

#endif